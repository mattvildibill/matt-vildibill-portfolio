"""Reproduce the four final n-body experiments. Python 3, NumPy, SciPy.

Run: python reproduce.py
Requires experiment.py, shoot.py, and build_data.py beside this script.
The same software versions were NumPy 2.3.5 and SciPy 1.17.0.
No accounts, external services, force softening, or downloads are used by this code.
Floating-point last digits can vary across platforms.
"""
import json, subprocess, sys
import numpy as np
from experiment import solve, metrics, OUT

subprocess.run([sys.executable,str(OUT/'shoot.py')],check=True)
m=np.array([3.,4.,5.])
q=np.array([[1.,3.],[-2.,-1.],[1.,-1.]])
q-=np.sum(q*m[:,None],axis=0)/np.sum(m)
v=np.zeros((3,2))
qp=q.copy();qp[0,0]+=.001
qp-=np.sum(qp*m[:,None],axis=0)/np.sum(m)

# The baseline and tighter run are integrated to 55, preserving the exact
# original adaptive-step setup, then trimmed to the verified interval [0,40].
# No claims are made about the discarded later segment.
a=solve(q,v,m,55,rtol=5e-14,n=1101)
r=solve(q,v,m,55,rtol=2.3e-14,n=1101)
b=solve(qp,v,m,40,rtol=5e-14,n=801)
br=solve(qp,v,m,40,rtol=2.3e-14,n=801)
assert all(s.success for s in [a,r,b,br])
def p(y):return y[:6].T.reshape(-1,3,2)
def rms(a,b):return np.sqrt(np.mean(np.sum((a-b)**2,axis=-1),axis=-1))
ay=a.y[:,:801];ry=r.y[:,:801]
np.savez(OUT/'chaos_final.npz',t=b.t,a=ay,b=b.y,ref=ry,q=q,v=v,m=m,diff=rms(p(ay),p(b.y)),num=rms(p(ay),p(ry)))
np.savez(OUT/'chaos_perturbed_check.npz',num=rms(p(b.y),p(br.y)),reference=br.y,energyDrift=metrics(b,m)['energyDrift'])
subprocess.run([sys.executable,str(OUT/'build_data.py')],check=True)
print('Recreated trajectories.json')
