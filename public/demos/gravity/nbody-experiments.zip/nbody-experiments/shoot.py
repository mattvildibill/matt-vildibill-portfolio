from experiment import *
q=np.array([[-.97000436,.24308753],[.97000436,-.24308753],[0,0]])
m=np.ones(3)
history=[]
def shoot(x,record=False):
    vx,vy,T=x
    v=np.array([[vx,vy],[vx,vy],[-2*vx,-2*vy]])
    s=solve(q,v,m,T,rtol=5e-14,n=2)
    err=s.y[:,-1]-s.y[:,0]
    if record:
        history.append({'parameters':x.tolist(),'stateResidualNorm':float(np.linalg.norm(err))})
    return err
x0=np.array([.465,.434,6.33])
def fun(x):return shoot(x,True)
r=least_squares(fun,x0,xtol=1e-13,ftol=1e-13,gtol=1e-13,diff_step=1e-5,max_nfev=50)
print('shoot',r.x,'initial residual',np.linalg.norm(shoot(x0)),'final',np.linalg.norm(shoot(r.x)),'nfev',r.nfev,'history',len(history),flush=True)
info={'parameters':r.x.tolist(),'initialParameters':x0.tolist(),'initialResidual':float(np.linalg.norm(shoot(x0))),'finalResidual':float(np.linalg.norm(shoot(r.x))),'nfev':r.nfev,'history':history}
(OUT/'shooting.json').write_text(json.dumps(info,indent=2))
