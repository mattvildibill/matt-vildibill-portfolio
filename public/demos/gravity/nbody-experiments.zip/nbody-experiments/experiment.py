import json, time
import numpy as np
from scipy.integrate import solve_ivp
from scipy.optimize import least_squares
from pathlib import Path

OUT=Path(__file__).parent

def rhs(t,y,m):
    q=y[:6].reshape(3,2)
    d=q[None,:,:]-q[:,None,:]
    rr=np.sum(d*d,axis=-1)
    np.fill_diagonal(rr,np.inf)
    a=np.sum(d*m[None,:,None]/rr[:,:,None]**1.5,axis=1)
    return np.concatenate((y[6:],a.ravel()))

def solve(q,v,m,T,rtol=1e-11,n=1101,atol=None):
    return solve_ivp(rhs,(0,T),np.concatenate((np.ravel(q),np.ravel(v))),args=(np.array(m),),method='DOP853',rtol=rtol,atol=atol or rtol*.01,t_eval=np.linspace(0,T,n))

def metrics(sol,m):
    q=sol.y[:6].T.reshape(-1,3,2);v=sol.y[6:].T.reshape(-1,3,2)
    m=np.array(m)
    E=.5*np.sum(v*v*m[None,:,None],axis=(1,2))
    dist=[]
    for i in range(3):
        for j in range(i):
            r=np.linalg.norm(q[:,i]-q[:,j],axis=-1)
            E-=m[i]*m[j]/r
            dist.append(r)
    return {'energy0':E[0],'energyDrift':np.abs(E-E[0])/abs(E[0]),'minSampledSeparation':float(np.min(dist))}

if __name__=='__main__':
    candidates=[
      ('burrau',[[1,3],[-2,-1],[1,-1]],np.zeros((3,2)),[3,4,5],50),
      ('chaosA',[[-1,0],[1,0],[0,.6]],[[.15,.3],[-.2,.05],[.05,-.35]],[1,1,1],40),
      ('chaosB',[[-1,0],[1,0],[0,1]],[[.2,.25],[-.1,.1],[-.1,-.35]],[1,1,1],60),
    ]
    for name,q,v,m,T in candidates:
        q=np.array(q,dtype=float);v=np.array(v,dtype=float)
        q-=np.sum(q*np.array(m)[:,None],axis=0)/sum(m)
        v-=np.sum(v*np.array(m)[:,None],axis=0)/sum(m)
        qp=q.copy();qp[0,0]+=1e-6;qp-=np.sum(qp*np.array(m)[:,None],axis=0)/sum(m)
        start=time.time()
        a=solve(q,v,m,T,rtol=3e-12);b=solve(qp,v,m,T,rtol=3e-12);ref=solve(q,v,m,T,rtol=3e-14)
        diff=np.sqrt(np.mean(np.sum((a.y[:6].T.reshape(-1,3,2)-b.y[:6].T.reshape(-1,3,2))**2,axis=2),axis=1))
        num=np.sqrt(np.mean(np.sum((a.y[:6].T.reshape(-1,3,2)-ref.y[:6].T.reshape(-1,3,2))**2,axis=2),axis=1))
        met=metrics(a,m)
        print(name,'success',a.success,b.success,ref.success,'nfev',a.nfev,b.nfev,ref.nfev,'elapsed',time.time()-start,'finaldiff',diff[-1],'maxdiff',max(diff),'maxnum',max(num),'E',max(met['energyDrift']),'mindist',met['minSampledSeparation'],flush=True)
        np.savez(OUT/f'{name}.npz',t=a.t,a=a.y,b=b.y,ref=ref.y,q=q,v=v,m=m,diff=diff,num=num)
