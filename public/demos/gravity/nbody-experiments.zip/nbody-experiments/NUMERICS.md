# Reproducing the numerical experiments

Use Python 3 with NumPy and SciPy. The recorded environment used NumPy 2.3.5
and SciPy 1.17.0. Put `reproduce.py`, `experiment.py`, `shoot.py`, and
`build_data.py` in the same folder. Run `python reproduce.py`. It recreates
`shooting.json`, the intermediate NumPy arrays, and `trajectories.json`.
An ordinary CPU suffices; no account or paid service is involved. Last digits
can vary across platforms and library versions.

All four cases use planar, unsoftened Newtonian point-mass gravity with G=1.
DOP853 is an adaptive eighth-order explicit Runge–Kutta integrator. Absolute
tolerance is 1% of relative tolerance. Diagnostic errors are calculated before
position coordinates are rounded to eight decimal places for display. The
animation interpolates saved positions; those display interpolations have no
claim to the accuracy of the saved numerical states.

## Exact rotating polygons

Equal unit masses start on a unit-radius regular polygon. Their angular rate is

omega^2 = (1/4) sum[k=1 to N-1] csc(pi*k/N).

The numerical result is compared with the analytic rotating polygon through
one period. This is a special exact solution for N=3 and N=8; it does not imply
stability to perturbations or an exact formula for arbitrary initial conditions.

## Figure-eight shooting

The known equal-mass figure-eight shape is used as a nearby starting point.
Positions are (-0.97000436,0.24308753), its negative, and (0,0). First and second
velocities are (vx,vy); the third velocity is -2 times that pair. A local
least-squares search adjusts vx, vy, and the period to reduce the Euclidean
norm of the final-minus-initial dimensionless 12-component position/velocity
state. It starts from (0.465,0.434,6.33). This is a numerical refinement of a
known periodic orbit, not the discovery of a new family or a mathematical
existence proof. The raw search history includes finite-difference Jacobian
evaluations and rejected candidates; its entries are not all accepted steps.

The search uses relative tolerance 5e-14 and returns a residual about 1.35e-13.
The playback trajectory uses relative tolerance 2e-13, checked against a
2.3e-14 run; its endpoint residual is therefore slightly different. The trial
overlay is shown at the same fraction of its own trial period 6.33, and its
separate sample times are available as trialTime.

## Chaotic three-body encounter

Burrau's Pythagorean initial conditions use masses 3,4,5 at (1,3),(-2,-1),(1,-1)
with zero velocities. Positions are shifted to their center-of-mass frame.
The comparison shifts the mass-3 body by +0.001 in x, then recenters all three
positions. This is 1/3000 of the shortest original pair distance, with an RMS
initial labeled-body separation of 0.0004787136.

Both baseline and perturbed integrations use relative tolerance 5e-14 and are
each compared with an independent rerun at 2.3e-14. The presented interval is
t=0 through t=40, selected to keep the numerical consistency differences small
while the physical perturbation grows visibly. Beyond that interval close
encounters can amplify roundoff and integration errors; no accuracy claim is
made for a longer prediction. The baseline and its reference retain a run
endpoint of 55 internally and discard data after 40, to preserve the adaptive
step setup of the recorded experiment.

At t=40 the two initial conditions differ by about 0.3888574 RMS position units,
roughly 812 times their initial RMS difference. This is a finite-time
sensitivity demonstration, not a measurement or proof of a Lyapunov exponent.

## Limits of the checks

- RMS position difference averages squared Euclidean errors over labeled bodies.
- Energy drift is absolute fractional change in kinetic plus potential energy.
- A tighter rerun is a consistency check, not a rigorous global error bound.
- Energy conservation alone does not guarantee trajectory accuracy.
- Minimum distance is measured only at saved times and can miss close approaches.
- These point masses have no radii; no relativity, collisions, or softening is used.
- None of these numerical results supplies a general closed-form n-body solution.
