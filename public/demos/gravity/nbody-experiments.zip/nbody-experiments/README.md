# What I could solve in the n-body problem

This investigation computes and checks four examples. It supplies an exact
special solution family and numerical solutions for specified initial conditions.
It does not supply a new general closed-form solution for arbitrary conditions.

## What “solvable” means

Newtonian point masses obey

\[
\ddot{\mathbf r}_i = G\sum_{j\ne i}m_j
\frac{\mathbf r_j-\mathbf r_i}{|\mathbf r_j-\mathbf r_i|^3}.
\]

For noncolliding initial positions and specified velocities, these differential
equations determine a unique local trajectory. Continuation is subject to
singularities. Numerical integration approximates a finite interval by repeatedly
evaluating those gravitational accelerations, with adaptive error control.

There is no generally useful universal closed-form recipe comparable to the
two-body reduction. Precise mathematical nonintegrability theorems rule out
certain classes of first integrals; they do not prove every imaginable form of
solution impossible. Convergent analytic series solutions already exist, beginning
with Sundman's three-body series result under additional conditions and extended by Wang. Existence of a
series and an efficient computational method are separate issues.

Chaos means sensitivity to nearby initial states. It does not introduce
randomness into Newton's equations, and not every three-body orbit is chaotic.

## An exact family for any finite n ≥ 2

Put n identical masses m on a regular polygon of radius R. For k=0,…,n−1, choose

\[
\mathbf r_k(t)=R\big(\cos(\omega t+2\pi k/n),\sin(\omega t+2\pi k/n)\big),
\qquad
\omega^2=\frac{Gm}{4R^3}\sum_{j=1}^{n-1}\frac{1}{\sin(\pi j/n)}.
\]

To check it, consider the body at (R,0). Its distance to body j is
2R sin(πj/n). The inward component of that body's gravitational acceleration is
Gm/[4R² sin(πj/n)]. Tangential components cancel in pairs. Summing the inward
components gives ω²R, exactly the acceleration of the proposed circular motion.
All bodies obey the same equation by rotational symmetry. Initial velocities
must match the derivative of this formula. Perturbation stability is a separate
question.

The three- and eight-body experiments integrate this motion numerically for
one revolution and compare against the exact formula.

## Measured results

| Experiment | Result |
| --- | --- |
| Exact triangle | Maximum RMS position discrepancy from formula: 4.39×10⁻¹³ |
| Exact eight-body polygon | Maximum RMS position discrepancy: 1.60×10⁻¹² |
| Figure-eight search | Return-to-start state residual: 0.006564 → 1.35×10⁻¹³ |
| Sensitive Burrau trio | Initial RMS difference 0.000478714 grows to 0.388857 by t=40, approximately 812× |
| Tighter Burrau reruns | Maximum RMS discrepancies: 3.23×10⁻⁶ baseline; 2.93×10⁻⁶ changed start |

The figure-eight search adjusts two velocity components and a period, integrates
one cycle, measures the final-minus-initial position-and-velocity vector, and
uses nonlinear least squares to reduce its norm. It numerically refines the
known equal-mass figure-eight orbit. The independent mathematical existence proof
belongs to Chenciner and Montgomery. Playback uses a different numerical tolerance,
so its closure residual is approximately 4.55×10⁻¹².

The sensitive example changes the mass-3 body's starting x coordinate by 0.001
and recenters the center of mass. This shift is 1/3000 of the shortest initial
pairwise distance. Both trajectories were rerun with tighter tolerances. The
final separation is over 120,000 times either observed solver disagreement.
Earlier candidates and longer intervals with inadequate numerical agreement were
excluded. The retained interval demonstrates finite-time sensitivity; it does
not prove a positive Lyapunov exponent or indefinite predictability.

## Verification and limits

See NUMERICS.md for tolerances, initial conditions, residual definitions, and
reproduction instructions. The reproducible Python workflow completed end to end.
The interactive replay's JavaScript passed checks for all scenario selections,
time scrubbing, comparison overlays, gravity directions, and playback stopping
at the endpoint. Its canvas was rendered at 736 and 360 pixels with a local
DOM-stub execution harness. A complete browser layout preview was blocked by
the browser's security policy and was not completed.

The animation interpolates saved, rounded samples for display. Its frames are
illustrations of computed motion, not full-precision numerical states. Diagnostics
are measured before display rounding. A tighter rerun is evidence of numerical
consistency, not a rigorous bound on true error. Low energy drift alone would
not establish accurate trajectories. This model omits finite radii, physical
collisions, relativity, and nongravitational forces.

## Sources

- [Wang, The global solution of the N-body problem](https://link.springer.com/article/10.1007/BF00048987)
- [Chenciner and Montgomery, A remarkable periodic solution of the three-body problem in the case of equal masses](https://annals.math.princeton.edu/articles/12364)
- [Tsygvintsev, The meromorphic non-integrability of the three-body problem](https://arxiv.org/abs/math/0009218)

The exact polygon calculation above is a direct verification of a known
central-configuration family. No claim of mathematical novelty is made.
