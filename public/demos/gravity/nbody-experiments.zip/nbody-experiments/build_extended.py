"""Generate replay assets for record-low figure-eight search and nearby futures.

python build_extended.py search
python build_extended.py ensemble

Uses only local NumPy/SciPy and existing shooting.json. No network access.
"""
import sys, json
import numpy as np
from experiment import OUT, solve, metrics

def positions(s): return s.y[:6].T.reshape(-1,3,2)
def rounded(a): return np.around(a,8).tolist()
def finish(name,data):
    path=OUT/(name+'.json')
    path.write_text(json.dumps(data,separators=(',',':'),allow_nan=False))
    print(name,'bytes',path.stat().st_size,flush=True)

def search():
    shot=json.loads((OUT/'shooting.json').read_text())
    q=np.array([[-.97000436,.24308753],[.97000436,-.24308753],[0,0]])
    m=np.ones(3)
    best=float('inf');candidates=[]
    for i,h in enumerate(shot['history']):
        if h['stateResidualNorm']>=best: continue
        best=h['stateResidualNorm']
        vx,vy,T=h['parameters'];v=np.array([[vx,vy],[vx,vy],[-2*vx,-2*vy]])
        s=solve(q,v,m,T,rtol=5e-14,n=201)
        assert s.success and np.isfinite(s.y).all()
        p=positions(s);dv=(s.y[6:,-1]-s.y[6:,0]).reshape(3,2)
        dp=p[-1]-p[0];met=metrics(s,m)
        candidate={
            'id':len(candidates),'evaluationNumber':i+1,
            'parameters':h['parameters'],'period':T,
            't':rounded(s.t),'positions':rounded(p),
            'initialVelocities':v.tolist(),
            'diagnostics':{
                'objectiveNorm':float(np.linalg.norm(s.y[:,-1]-s.y[:,0])),
                'recordedObjectiveNorm':h['stateResidualNorm'],
                'positionClosureNorm':float(np.linalg.norm(dp)),
                'positionClosureRms':float(np.sqrt(np.mean(np.sum(dp*dp,axis=1)))),
                'velocityClosureNorm':float(np.linalg.norm(dv)),
                'finalPositions':p[-1].tolist(),
                'finalVelocities':s.y[6:,-1].reshape(3,2).tolist(),
                'positionMiss':dp.tolist(),'velocityMiss':dv.tolist(),
                'maxEnergyDrift':float(max(met['energyDrift'])),
                'minSampledSeparation':met['minSampledSeparation'],
                'functionEvaluations':s.nfev,'integrationSuccess':bool(s.success)
            }
        }
        candidates.append(candidate)
        print('search candidate',len(candidates),'evaluation',i+1,'objective',candidate['diagnostics']['objectiveNorm'],'position closure',candidate['diagnostics']['positionClosureNorm'],flush=True)
    data={
        'method':{
            'label':'Record-low objective candidates from a local numerical shooting search',
            'G':1,'integrator':'DOP853','rtol':5e-14,'atol':5e-16,
            'objective':'Euclidean norm of final-minus-initial dimensionless 12-component position and velocity state.',
            'selection':'Eight successive record-low objective values from the recorded function-evaluation history; these are not all solver iterations.',
            'inset':'Use full-precision positionMiss vectors for magnified closure insets. Rounded path endpoints can coincide even when the computed miss is nonzero.',
            'time':'Each candidate is integrated over its own trial period. Compare playbacks at equal fractional progress.',
            'limitations':['Refines a nearby known equal-mass figure-eight; no new orbit discovery is claimed.','Finite-precision residuals are numerical consistency measures, not rigorous existence or error proofs.','Path coordinates are rounded to eight decimal places. Diagnostic endpoints and misses retain full floating-point precision.','A magnified endpoint inset must label its magnification or local scale.']
        },
        'initialPositions':q.tolist(),'masses':m.tolist(),'candidates':candidates,
        'summary':{
            'candidateCount':len(candidates),'totalRecordedFunctionEvaluations':len(shot['history']),
            'initialObjective':candidates[0]['diagnostics']['objectiveNorm'],
            'finalObjective':candidates[-1]['diagnostics']['objectiveNorm'],
            'improvementFactor':candidates[0]['diagnostics']['objectiveNorm']/candidates[-1]['diagnostics']['objectiveNorm']
        }
    }
    finish('search',data)

def ensemble():
    m=np.array([3.,4.,5.]);q=np.array([[1.,3.],[-2.,-1.],[1.,-1.]])
    q-=np.sum(q*m[:,None],axis=0)/np.sum(m);v=np.zeros((3,2))
    T=40.;n=501;amount=.001;members=[]
    # Baseline uses the same previous 55-time-unit adaptive integration setup.
    # Dense evaluation at the ensemble sample times avoids rounding or interpolation.
    from scipy.integrate import solve_ivp
    from experiment import rhs
    baseline=solve_ivp(rhs,(0,55),np.r_[q.ravel(),v.ravel()],args=(m,),method='DOP853',rtol=5e-14,atol=5e-16,t_eval=np.linspace(0,T,n))
    assert baseline.success and np.isfinite(baseline.y).all()
    bp=positions(baseline)
    for k in range(8):
        angle=k*np.pi/4;delta=amount*np.array([np.cos(angle),np.sin(angle)])
        qp=q.copy();qp[0]+=delta;qp-=np.sum(qp*m[:,None],axis=0)/sum(m)
        s=solve(qp,v,m,T,rtol=5e-14,n=n)
        assert s.success and np.isfinite(s.y).all(),f'Integration failed: direction {k}'
        p=positions(s);met=metrics(s,m)
        gap=np.sqrt(np.mean(np.sum((p-bp)**2,axis=2),axis=1))
        member={
            'id':k,'angleDegrees':k*45,'displacement':delta.tolist(),
            'initialPositions':qp.tolist(),'positions':rounded(p),
            'diagnostics':{
                'integrationSuccess':bool(s.success),'allFinite':bool(np.isfinite(s.y).all()),
                'functionEvaluations':s.nfev,'initialEnergy':float(met['energy0']),
                'maxEnergyDrift':float(max(met['energyDrift'])),
                'minSampledSeparation':met['minSampledSeparation'],
                'initialRmsSeparation':float(gap[0]),'finalRmsSeparation':float(gap[-1]),
                'maxRmsSeparation':float(max(gap)),
                'separation':gap.tolist(),
                'maxAbsoluteCoordinate':float(np.max(np.abs(p)))
            }
        }
        members.append(member)
        print('ensemble',k*45,'deg','final RMS',gap[-1],'energy drift',member['diagnostics']['maxEnergyDrift'],'finite',member['diagnostics']['allFinite'],flush=True)
    arr=np.array([m['positions'] for m in members])
    centroids=arr.mean(axis=0)
    spread=np.sqrt(np.mean(np.sum((arr-centroids[None,...])**2,axis=-1),axis=(0,2)))
    data={
        'method':{
            'label':'Eight deterministic nearby initial conditions for Burrau three-body encounter',
            'G':1,'integrator':'DOP853','rtol':5e-14,'atol':5e-16,'forceSoftening':0,
            'sampling':'Eight equally spaced directions in the starting x/y plane; mass-3 body moves exactly 0.001, then all positions are recentered on their center of mass.',
            'initialScale':'Shortest initial pair separation is 3; each nudge is 1/3000 of that length.',
            'energyMetric':'Maximum saved-sample absolute fractional energy change from the initial kinetic plus potential energy.',
            'separationMetric':'RMS Euclidean displacement across corresponding labeled bodies relative to the unperturbed run at the same time.',
            'limitations':['This is a deterministic illustration, not a probability distribution or uncertainty forecast.','Energy conservation and successful finite integrations do not prove accurate trajectories or provide rigorous error bounds.','Individual members have not each been independently checked at a tighter tolerance.','Minimum separation is measured at saved times and may miss a closer approach between samples.','Position samples are rounded to eight decimal places; animation interpolation adds display error.','No physical radii, collision resolution, relativity, or force softening is included.']
        },
        'masses':m.tolist(),'initialPositions':q.tolist(),'initialVelocities':v.tolist(),
        't':rounded(baseline.t),'baselinePositions':rounded(bp),'members':members,
        'summary':{
            'memberCount':8,'allIntegrationsSuccessful':all(m['diagnostics']['integrationSuccess'] for m in members),
            'allSamplesFinite':all(m['diagnostics']['allFinite'] for m in members),
            'maximumMemberEnergyDrift':max(m['diagnostics']['maxEnergyDrift'] for m in members),
            'minimumFinalRmsSeparation':min(m['diagnostics']['finalRmsSeparation'] for m in members),
            'maximumFinalRmsSeparation':max(m['diagnostics']['finalRmsSeparation'] for m in members),
            'finalEnsembleRmsSpread':float(spread[-1]),
            'ensembleRmsSpread':spread.tolist()
        }
    }
    finish('ensemble',data)

if __name__=='__main__':
    {'search':search,'ensemble':ensemble}[sys.argv[1]]()
