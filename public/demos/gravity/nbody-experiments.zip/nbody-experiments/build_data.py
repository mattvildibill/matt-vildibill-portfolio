import json, numpy as np
from scipy.integrate import solve_ivp
from pathlib import Path
OUT=Path(__file__).parent

def rhs(t,y,m):
    n=len(m);q=y[:2*n].reshape(n,2)
    d=q[None,:,:]-q[:,None,:];rr=np.sum(d*d,axis=-1);np.fill_diagonal(rr,np.inf)
    return np.r_[y[2*n:],np.sum(d*m[None,:,None]/rr[:,:,None]**1.5,axis=1).ravel()]

def integrate(q,v,m,T,n,rtol=2e-13):
    return solve_ivp(rhs,(0,T),np.r_[np.ravel(q),np.ravel(v)],args=(np.array(m),),method='DOP853',rtol=rtol,atol=rtol*.01,t_eval=np.linspace(0,T,n))

def pos(y,m):return y[:2*len(m)].T.reshape(-1,len(m),2)
def rms(p,p2):return np.sqrt(np.mean(np.sum((p-p2)**2,axis=-1),axis=-1))
def rnd(a):return np.around(a,8).tolist()

def make_scenario(id,title,t,y,m,q,v,reference=None,perturbed=None):
    n=len(m);p=pos(y,m);vel=y[2*n:].T.reshape(-1,n,2)
    E=.5*np.sum(vel*vel*np.array(m)[None,:,None],axis=(1,2));ds=[]
    for i in range(n):
        for j in range(i):
            d=np.linalg.norm(p[:,i]-p[:,j],axis=-1);ds.append(d);E-=m[i]*m[j]/d
    dE=np.abs(E-E[0])/abs(E[0]);num=rms(p,reference) if reference is not None else np.zeros(len(t))
    s={'id':id,'title':title,'t':np.around(t,8).tolist(),'positions':rnd(p),'masses':list(map(float,m)),'initial':{'positions':np.asarray(q).tolist(),'velocities':np.asarray(v).tolist()},'diagnostics':{'numericalError':num.tolist(),'energyDrift':dE.tolist(),'initialEnergy':float(E[0]),'maxNumericalError':float(max(num)),'maxEnergyDrift':float(max(dE)),'minSampledSeparation':float(np.min(ds))},'summary':{}}
    if perturbed is not None:
        sep=rms(p,perturbed);s['perturbed']=rnd(perturbed);s['diagnostics']['separation']=sep.tolist();s['diagnostics']['maxSeparation']=float(max(sep));s['diagnostics']['finalSeparation']=float(sep[-1])
    return s

scenarios=[]
for n,id,title in [(3,'triangle','Exact rotating triangle'),(8,'ring','Exact eight-body ring')]:
    ang=np.arange(n)*2*np.pi/n;q=np.c_[np.cos(ang),np.sin(ang)];m=np.ones(n)
    omega=np.sqrt(.25*np.sum(1/np.sin(np.pi*np.arange(1,n)/n)));T=2*np.pi/omega
    v=omega*np.c_[-np.sin(ang),np.cos(ang)]
    sol=integrate(q,v,m,T,501)
    exact=np.stack([np.cos(ang[None,:]+omega*sol.t[:,None]),np.sin(ang[None,:]+omega*sol.t[:,None])],axis=-1)
    s=make_scenario(id,title,sol.t,sol.y,m,q,v,reference=exact)
    s['summary']={'period':T,'omega':omega,'checkType':'numerical versus exact rotating polygon','rtol':2e-13,'functionEvaluations':sol.nfev,'maxPositionError':s['diagnostics']['maxNumericalError'],'periodicResidual':float(np.linalg.norm(sol.y[:,-1]-sol.y[:,0]))}
    scenarios.append(s)

shot=json.loads((OUT/'shooting.json').read_text());vx,vy,T=shot['parameters'];q=np.array([[-.97000436,.24308753],[.97000436,-.24308753],[0,0]])
v=np.array([[vx,vy],[vx,vy],[-2*vx,-2*vy]]);m=np.ones(3)
sol=integrate(q,v,m,T,801);ref=integrate(q,v,m,T,801,rtol=2.3e-14)
ix,iy,iT=shot['initialParameters'];iv=np.array([[ix,iy],[ix,iy],[-2*ix,-2*iy]])
trial=integrate(q,iv,m,iT,801)
s=make_scenario('figure8','A figure-eight found by shooting',sol.t,sol.y,m,q,v,reference=pos(ref.y,m))
s['perturbed']=rnd(pos(trial.y,m));s['trialTime']=np.around(trial.t,8).tolist();s['summary']={'period':T,'checkType':'numerical versus tighter rerun','rtol':2e-13,'referenceRtol':2.3e-14,'comparison':'The nearby initial guess, shown at the same fraction of its own trial period, before shooting refinement.','shooting':shot,'periodicResidual':float(np.linalg.norm(sol.y[:,-1]-sol.y[:,0]))}
scenarios.append(s)

chaos=np.load(OUT/'chaos_final.npz')
last=len(chaos['t'])
ix=np.unique(np.linspace(0,last-1,min(901,last),dtype=int))
q=chaos['q'];v=chaos['v'];m=chaos['m'];t=chaos['t'][ix];a=chaos['a'][:,ix];b=chaos['b'][:,ix];ref=chaos['ref'][:,ix]
s=make_scenario('chaos','A tiny change becomes a different future',t,a,m,q,v,reference=pos(ref,m),perturbed=pos(b,m))
s['initial']['perturbation']={'body':0,'axis':'x','amount':.001,'centerOfMassRecentered':True,'description':'Move the mass-3 body by +0.001 in x (1/3000 of the shortest initial separation), then subtract the new center of mass from all positions.'}
s['summary']={'checkType':'numerical versus tighter rerun','rtol':5e-14,'referenceRtol':2.3e-14,'initialRmsPerturbation':s['diagnostics']['separation'][0],'finalRmsSeparation':s['diagnostics']['finalSeparation'],'endTime':float(t[-1]),'maxNumericalError':s['diagnostics']['maxNumericalError'],'maxEnergyDrift':s['diagnostics']['maxEnergyDrift'],'name':'Burrau Pythagorean three-body initial conditions','unshiftedPositions':[[1,3],[-2,-1],[1,-1]]}
if (OUT/'chaos_perturbed_check.npz').exists():
    check=np.load(OUT/'chaos_perturbed_check.npz')
    s['diagnostics']['perturbedNumericalError']=check['num'][ix].tolist()
    s['diagnostics']['maxPerturbedNumericalError']=float(max(check['num']))
    s['diagnostics']['perturbedEnergyDrift']=check['energyDrift'][ix].tolist()
    s['diagnostics']['maxPerturbedEnergyDrift']=float(max(check['energyDrift']))
scenarios.append(s)

data={'method':{'force':'Unsoftened Newtonian gravity','G':1,'dimensions':2,'integrator':'SciPy solve_ivp DOP853 (explicit eighth-order adaptive Runge-Kutta)','atol':'rtol × 0.01','positionUnits':'Initial rotating-polygon radius = 1; chaos initial pair separation = 2.','errorMetric':'RMS Euclidean position difference across labeled bodies, before 8-decimal display rounding.','energyMetric':'Absolute fractional drift from initial total kinetic plus potential energy.','limitations':['Finite-horizon floating-point integrations are approximations, not proofs of a general closed-form solution.','A tighter rerun is a numerical consistency check, not a rigorous global error bound.','Minimum separation is measured at saved sample times and may miss closer encounters between them.','All curves use the Newtonian point-mass model with no force softening, relativity, or physical collisions.','Figure-eight shooting finds a nearby known periodic orbit using a local numerical least-squares solver; it is not a discovery of a new orbit.']},'scenarios':scenarios}
(OUT/'trajectories.json').write_text(json.dumps(data,separators=(',',':')))
print('bytes', (OUT/'trajectories.json').stat().st_size)
for s in scenarios: print(s['id'],'max numerical error',s['diagnostics']['maxNumericalError'],'max energy drift',s['diagnostics']['maxEnergyDrift'])
